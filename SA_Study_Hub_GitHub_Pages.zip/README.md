# SA Study Hub — Grade 10

A browser-based Grade 10 study and practice website for South African learners.

## GitHub Pages publishing

1. Create a new GitHub repository, for example `sa-study-hub`.
2. Upload `index.html` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/ (root)` folder.
6. Save and wait for GitHub Pages to deploy.
7. Open the Pages URL shown by GitHub.

The site is self-contained: the main website is in `index.html`, so no server or database is required for the built-in browser features.

## Included

- Grade 10 practice mode
- 50 practice questions per subject
- 13 subjects / 650 practice questions
- XP and levels
- Accuracy/progress tracking
- Timed practice/exam features
- Mobile-friendly layout
- Browser local storage for progress

## Important

Student progress is stored locally in the browser. It is not shared between devices or stored on a server.
